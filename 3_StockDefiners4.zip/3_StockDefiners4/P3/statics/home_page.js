
$(document).ready(function(){

    
    $("#search_button").click(function(){
        var word = $("#word").val();
l
        $.ajax({
            url: "./def/" + word,
            type: "GET",
            dataType: "json",
        
            success: function(data){
                $("#def_name").text(word)
                $("#def_descr").text(data);
            },
            error: function(error){
                $("#def_name").text("No definition")
                $("#def_descr").text("There has been no definition found.");
            }
        });
    });


});


$(document).ready(function(){

    
    $(".search_link").click(function(){
        var word = $(this).text();

        
        $.ajax({
            url: "./def/" + word,
            type: "GET",
            dataType: "json",
           
            success: function(data){
                $("#def_name").text(word)
                $("#def_descr").text(data);
            },
            error: function(error){
                $("#def_name").text("No definition")
                $("#def_descr").text("There has been no definition found.");
            }
        });
    });


});





    
