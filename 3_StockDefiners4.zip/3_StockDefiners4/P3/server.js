const express = require('express')
const app = express()
const path = require("path")


app.use(express.static(path.join(__dirname,'statics')))

var definitions = require('./definitions.json');


app.get('/', (req, res) => {
    res.sendFile( path.join( __dirname, 'home_page.html' ));
})

app.get('/other resources', (req, res) => {
    res.sendFile( path.join( __dirname, 'jaylens_code.html' ));
})

app.get('/help', (req, res) => {
    res.sendFile( path.join( __dirname, 'help.html' ));
})

app.get('/definit', (req, res) => {
    res.sendFile( path.join( __dirname, 'home_page.html' ));
})

app.get('/about', (req, res) => {
    res.sendFile( path.join( __dirname, 'about.html' ));
})


app.get('/def/:def_id', (req, res) => {
    

    res.header("Content-Type",'application/json');
    

    if(definitions[req.params.def_id]){
        res.send(JSON.stringify(definitions[req.params.def_id]));
    }else{
        res.send("");
    }
})


app.listen(8000)